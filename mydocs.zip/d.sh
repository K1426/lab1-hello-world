
for i in {1..14}
do

myurl="https://artlapsa.com/storage/series/webtoon/bb928eef-56aa-48d1-90ca-3a300ac87aa1/chapters/e5061399-5e02-4fce-bba3-d3de0765d9ce/"

if [ $i -lt 10 ]; then
myurl+=00
else
myurl+=0
fi

myurl+=$i
myurl+=".jpg"
wget -q $myurl

printf "%d " $i

done

echo ""
