import tkinter as tk


main_window = tk.Tk()

message = tk.Label(main_window, text = "hello world")
message.pack()

main_window.title("khadija")

main_window_h = 400
main_window_w = 600

screen_w = main_window.winfo_screenwidth()
screen_h = main_window.winfo_screenheight()

x = (screen_w - main_window_w) // 2
y = (screen_h - main_window_h) // 2

main_window.geometry(f"{main_window_w}x{main_window_h}+{x}+{y}")
main_window.mainloop()
